import java.util.HashSet;

public class Activity3 {
    public static void main(String[] args){

    }
    public static HashSet<Integer> intersect(HashSet<Integer>,a){

    }
}
