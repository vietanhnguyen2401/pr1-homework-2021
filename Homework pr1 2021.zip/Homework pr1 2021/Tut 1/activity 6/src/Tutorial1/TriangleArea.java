package Tutorial1;

public class TriangleArea {
    public static void main(String [] args) {
        double base = 3;
        double height = 1.5;
        double area = (base* height)/2;
        String intro;
        intro = "It's area (cm2) is: ";
        System.out.println("The triangle's base is 3 (cm) and height is 1.5 (cm)");
        System.out.println(intro);
        System.out.println(area);
    }
}
