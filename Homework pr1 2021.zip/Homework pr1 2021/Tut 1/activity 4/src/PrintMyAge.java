import java.time.LocalDate;
import java.time.Month;

public class PrintMyAge {
    public static void main (String[] args) {
        int var0 = 2001;
        int var1 = 2021;
        String intro ="Therefore my age is: ";
        System.out.println("I was born in 2001. This year is 2021");
        System.out.println(intro);
        System.out.println(var1 - var0);
    }
}
