package Tutorial1;

public class MoneyEquivalent {
    public static void main (String [] args) {
        int var1= 1200000;
        int var2= 207;
        String intro = "The amount of JPY for 1,200,000 VND is:";
        System.out.println(intro);
        System.out.println(var1/var2);
    }
}
