public class greeting {
    public static void main(String[] args) {
        String myName = "Nguyen Viet Anh";
        String mob = "January 24th";
        int yob = 2001;
        String intro = "I'm from Hanoi. I went to Hanoi University";
        System.out.println("Hi, my name is " + myName + ".");
        System.out.println("I was born in " + mob + ", " + yob + ".");
        System.out.println(intro);
    }

}
